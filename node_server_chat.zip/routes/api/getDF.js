const express = require("express");
const router = express.Router();
const g_authenticator = require("google-auth-library")

const dialogflow = require('dialogflow');
const uuid = require('uuid');

router.use("/getDF", (req, res, next) => {
    console.log('inside router');

let payload={
    success:"ok"
}
res.send(JSON.stringify(payload));
});

module.exports = router;